<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><!-- InstanceBegin template="/Templates/temp1.dwt.php" codeOutsideHTMLIsLocked="false" -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!-- InstanceBeginEditable name="doctitle" -->
<title>Untitled Document</title>
<style type="text/css">
#planquicklook
{
font: bold 20px sans-serif;
position:relative;
top:-350px;
left:620px
}

#image
{
	position:relative;
	top:-80px;
	left:10px;
}
#extrafeatures
{
	position:relative;
	top:170px;
	left:130px
}
#planquicklook th
{
	font-size:16px;
}
#planquicklook a
{
	font-size:20px;
}
#balancetable
{
	position:relative;
	top:-30px;
	left:-130px
}

#datetable
{
	font: bold 1em sans-serif;
	border-collapse:collapse;
}
#callhistory
{
	font-family:sans-serif;
	width:100%;
	border-collapse:collapse;
}
#callhistory td, #callhistory th 
{
font-size:1em;
border:1px solid #98bf21;
padding:3px 7px 2px 7px;
}
#callhistory th 
{
	font-family:sans-serif;
	font-size:0.7em;
	text-align:left;
	padding-top:5px;
	padding-bottom:4px;
	background-color:#A7C942;
	color:#ffffff;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
}
#callhistory tr.alt td 
{
color:#000000;
background-color:#EAF2D3;
}
/* BeginOAWidget_Instance_2137022: #datepicker */
		#datepicker .ui-widget {
			font-family: inherit;
		}
			
		#datepicker .ui-datepicker {
			font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		}
		
		#datepicker .ui-datepicker-title {
			font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
			font-size: 1.1em;
			color: #000;
			font-weight: normal;
			line-height: 1.8em;
		}


		#datepicker .ui-state-default, .ui-widget-content .ui-state-default {
			border-color: #e6e6e6;
			background-color: #e6e6e6;
			color: #555555;
		}
		
		#datepicker .ui-state-default, .ui-state-default a {
			color: #555555;
		}	
		
			
		#datepicker .ui-state-highlight, .ui-widget-content .ui-state-highlight {
			border-color:#FCEFA1;
			background-color:#FCEFA1;
			color:#363636;
		}		
		
		#datepicker .ui-state-active, .ui-widget-content .ui-state-active { 
			border-color: #FFFFFF;
			background-color: #FFFFFF;
			color: #212121; 
		}
		
		#datepicker .ui-state-hover, .ui-widget-content .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus 	
		{
			border-color: #5F5F5F;
			background-color: #5F5F5F;
			color: #212121;
		}
		
		#datepicker .ui-widget-header 	
		{
			border-color: #5F5F5F;
			background-color: #808080;
			border-width: 1px;
		}
		
		/* Text attributes for the Days of Week Text */ 
		#datepicker .ui-datepicker table th
		{
			font-size: .8em;
			color: #000;
			font-weight: bold;
		}
		
		
		
/* EndOAWidget_Instance_2137022 */
</style>
<style type="text/css">
/* BeginOAWidget_Instance_2137022: #datepicker_2 */

		#datepicker_2 .ui-widget {
			font-family: inherit;
		}
			
		#datepicker_2 .ui-datepicker {
			font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		}
		
		#datepicker_2 .ui-datepicker-title {
			font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
			font-size: 1.1em;
			color: #000;
			font-weight: normal;
			line-height: 1.8em;
		}


		#datepicker_2 .ui-state-default, .ui-widget-content .ui-state-default {
			border-color: #e6e6e6;
			background-color: #e6e6e6;
			color: #555555;
		}
		
		#datepicker_2 .ui-state-default, .ui-state-default a {
			color: #555555;
		}	
		
			
		#datepicker_2 .ui-state-highlight, .ui-widget-content .ui-state-highlight {
			border-color:#FCEFA1;
			background-color:#FCEFA1;
			color:#363636;
		}		
		
		#datepicker_2 .ui-state-active, .ui-widget-content .ui-state-active { 
			border-color: #FFFFFF;
			background-color: #FFFFFF;
			color: #212121; 
		}
		
		#datepicker_2 .ui-state-hover, .ui-widget-content .ui-state-hover, .ui-state-focus, .ui-widget-content .ui-state-focus 	
		{
			border-color: #5F5F5F;
			background-color: #5F5F5F;
			color: #212121;
		}
		
		#datepicker_2 .ui-widget-header 	
		{
			border-color: #5F5F5F;
			background-color: #808080;
			border-width: 1px;
		}
		
		/* Text attributes for the Days of Week Text */ 
		#datepicker_2 .ui-datepicker table th
		{
			font-size: .8em;
			color: #000;
			font-weight: bold;
		}
		
		
		
/* EndOAWidget_Instance_2137022 */
.container .content #TabbedPanels1 .TabbedPanelsContentGroup .TabbedPanelsContent.TabbedPanelsContentVisible #TabbedPanels2 .TabbedPanelsContentGroup .TabbedPanelsContent.TabbedPanelsContentVisible table tr th table tr td h4 {
	font-size: 75%;
}
.container .content #TabbedPanels1 .TabbedPanelsContentGroup .TabbedPanelsContent.TabbedPanelsContentVisible #TabbedPanels2 .TabbedPanelsContentGroup .TabbedPanelsContent.TabbedPanelsContentVisible table tr th table tr td {
	font-size: 75%;
}
.plano {
}
.planometer {
	color: #CC0000;
}
</style>
<!-- InstanceEndEditable -->
<style type="text/css">
<!--
body {
	font: 100%/1.4 Verdana, Arial, Helvetica, sans-serif;
	background: #42413C;
	margin: 0;
	padding: 0;
	color: #000;
}

/* ~~ Element/tag selectors ~~ */
ul, ol, dl { /* Due to variations between browsers, it's best practices to zero padding and margin on lists. For consistency, you can either specify the amounts you want here, or on the list items (LI, DT, DD) they contain. Remember that what you do here will cascade to the .nav list unless you write a more specific selector. */
	padding: 0;
	margin: 0;
}
h1, h2, h3, h4, h5, h6, p {
	margin-top: 0;	 /* removing the top margin gets around an issue where margins can escape from their containing div. The remaining bottom margin will hold it away from any elements that follow. */
	padding-right: 15px;
	padding-left: 15px; /* adding the padding to the sides of the elements within the divs, instead of the divs themselves, gets rid of any box model math. A nested div with side padding can also be used as an alternate method. */
}
a img { /* this selector removes the default blue border displayed in some browsers around an image when it is surrounded by a link */
	border: none;
}
/* ~~ Styling for your site's links must remain in this order - including the group of selectors that create the hover effect. ~~ */
a:link {
	color: #42413C;
	text-decoration: underline; /* unless you style your links to look extremely unique, it's best to provide underlines for quick visual identification */
}
a:visited {
	color: #6E6C64;
	text-decoration: underline;
}
a:hover, a:active, a:focus { /* this group of selectors will give a keyboard navigator the same hover experience as the person using a mouse. */
	text-decoration: none;
}

/* ~~ this fixed width container surrounds the other divs ~~ */
.container {
	width: 960px;
	background: #FFF;
	margin: 0 auto; /* the auto value on the sides, coupled with the width, centers the layout */
}

/* ~~ the header is not given a width. It will extend the full width of your layout. It contains an image placeholder that should be replaced with your own linked logo ~~ */
.header {
	background: #ADB96E;
}

/* ~~ This is the layout information. ~~ 

1) Padding is only placed on the top and/or bottom of the div. The elements within this div have padding on their sides. This saves you from any "box model math". Keep in mind, if you add any side padding or border to the div itself, it will be added to the width you define to create the *total* width. You may also choose to remove the padding on the element in the div and place a second div within it with no width and the padding necessary for your design.

*/

.content {

	padding: 10px 0;
}

/* ~~ The footer ~~ */
.footer {
	padding: 10px 0;
	background: #CCC49F;
}

/* ~~ miscellaneous float/clear classes ~~ */
.fltrt {  /* this class can be used to float an element right in your page. The floated element must precede the element it should be next to on the page. */
	float: right;
	margin-left: 8px;
}
.fltlft { /* this class can be used to float an element left in your page. The floated element must precede the element it should be next to on the page. */
	float: left;
	margin-right: 8px;
}
.clearfloat { /* this class can be placed on a <br /> or empty div as the final element following the last floated div (within the #container) if the #footer is removed or taken out of the #container */
	clear:both;
	height:0;
	font-size: 1px;
	line-height: 0px;
}
-->
</style>
<script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<!-- InstanceBeginEditable name="head" -->
<script src="jquery-ui-1.7.2/js/jquery-1.3.2.min.js" type="text/javascript"></script>
<script src="jquery-ui-1.7.2/js/jquery-ui-1.7.2.min.js" type="text/javascript"></script>
<link href="jquery-ui-1.7.2/css/base/ui.core.css" rel="stylesheet" type="text/css" />
<link href="jquery-ui-1.7.2/css/base/ui.datepicker.css" rel="stylesheet" type="text/css" />
<link href="jquery-ui-1.7.2/css/base/ui.theme.css" rel="stylesheet" type="text/css" />
<link href="jquery-ui-1.7.2/css/base/ui.datepicker.images.css" rel="stylesheet" type="text/css" />
<script type="text/xml">
<!--
<oa:widgets>
  <oa:widget wid="2137022" binding="#datepicker" />
  <oa:widget wid="2137022" binding="#datepicker_2" />
</oa:widgets>
-->
</script>
<!-- InstanceEndEditable -->
</head>

<body>

<div class="container">
  <div class="header"><a href="#"><img src="images/mtnl_logo.png" alt="Insert Logo Here" name="Insert_logo" width="391" height="66" id="Insert_logo" style="background: #C6D580; display:block;" /></a>
  <!-- end .header --></div>
  <div class="content">
    <div id="TabbedPanels1" class="TabbedPanels">
      <ul class="TabbedPanelsTabGroup">
        <li class="TabbedPanelsTab" tabindex="0">My Account</li>
        <li class="TabbedPanelsTab" tabindex="0">Individual</li>
        <li class="TabbedPanelsTab" tabindex="0">Business</li>
      </ul>
      <div class="TabbedPanelsContentGroup">
        <div class="TabbedPanelsContent">
          <div id="TabbedPanels2" class="TabbedPanels">
            <ul class="TabbedPanelsTabGroup">
              <li class="TabbedPanelsTab" tabindex="0"><a href="Task1-Account summary.php" target="_self">Account Summary</a></li>
              <li class="TabbedPanelsTab" tabindex="0"> Account Usage</li>
              <li class="TabbedPanelsTab" tabindex="0">Pay  Your Bills</li>
              <li class="TabbedPanelsTab" tabindex="0">Billig History</li>
              <li class="TabbedPanelsTab" tabindex="0">Services</li>
              <li class="TabbedPanelsTab" tabindex="0">Profile</li>
            </ul>
            <div class="TabbedPanelsContentGroup">
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="ASEdit" -->
               <div id="breadcrumbs"> 
                  <h5><a href="#">My Account</a> &gt;Account Summary
                  </h5>
                </div>
                  <table width="937" height="659" border="0">
                    <tr>
                      <th height="655" align="left" scope="row"><h3>WELCOME SITA,</h3>
                          <table width="333" height="123" border="0" align="center" id="balancetable" >
                          <tr>
                            <th  align="center" width="435"  scope="row">
                             <h5>TOTAL BALANCE DUE: Rs 1000</h5>
                            <h6>(09/15/2011) - (10/15/2011)</h6>
                            <h5><input type="submit" name="button" id="button" value="Make a Payment " /></h5>
                           </th>
                          </tr>
                        
                        </table>
                        <br>
                        <table width="587" border="2" id="extrafeatures" name="extrafeatures">
                          <tr>
                            <td width="165" height="61"><form id="form1" name="form1" method="post" action="">
                              <blockquote>
                                <p>
                                  <input type="submit" name="Button1" id="Button1" value="Manage Profile" />
                                </p>
                              </blockquote>
                            </form></td>
                            <td width="174"><blockquote>
                              <p>
                                <input type="submit" name="Button2" id="Button2" value="Manage Plan" />
                              </p>
</blockquote></td>
                            <td width="226"><blockquote>
                              <p>
                                <input type="submit" name="Button3" id="Button3" value="Manage Profile" />
                              </p>
</blockquote></td>
                          </tr>
                          <tr>
                            <td height="76"><blockquote>
                              <p>
                                <input type="submit" name="Button4" id="Button4" value="Manage AutoPay" />
                              </p>
</blockquote></td>
                            <td><blockquote>
                              <p>
                                <input type="submit" name="Button5" id="Button5" value="View Offers" />
                              </p>
                            </blockquote></td>
                            <td><blockquote>
                              <p>
                                <input type="submit" name="Button6" id="Button6" value="Contact Us" />
                              </p>
                            </blockquote></td>
                          </tr>
                        </table>
<p>&nbsp;</p>
<table id="planquicklook" width="320" height="220" border="1">
                        <tr>
                            <th width="908" height="34" scope="row"><h3>QUICK LOOK OF YOUR PLANS</h3></th>
                        </tr>
                          <tr>
                            <td align="LEFT" bgcolor="#FFFFCC" scope="row">Mobile-</td>
                          </tr>
                          <tr>
                            <td align="LEFT" scope="row" ><h4><a href="Task1-Account Summary.php" >Garuda 9901317127 </a><br/>
                              Balance due :  Rs 650 <br />
                              Due Date : 11/03/2011
                               <input  type="submit" name="button2" id="button2" value="Quick Payment" />
                            </td>
                          </tr>
                          <tr>
                            <td align="LEFT" bgcolor="#FFFFCC" scope="row">Internet-</td>
                          </tr>
                          <tr>
                            <td align="LEFT" scope="row"><h4><a href="Task1-Account Summary.php">Broadband Freedom 769 </a><br/>
                              Balance due :  Rs 350 <br />
                              Due Date : 11/03/2011
                                <input  type="submit" name="button3" id="button3" value="Quick Payment" />
                            </td>
                          </tr>
                        </table></th>
                    </tr>
                  </table>
                
              <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="AUEdit" -->
                <h5 align="center">YOUR PLANS&nbsp;  <a href="planometer2.php" class="plano"> <span class="planometer">Plano-o-meter</span></a></h5>
                <div   id="TabbedPanels4" class="VTabbedPanels">
                  <ul align="center" class="TabbedPanelsTabGroup">
                    <li class="TabbedPanelsTab" tabindex="0">BroadBand Freedom 769</li>
                    <li class="TabbedPanelsTab" tabindex="0">Garuda 9901317127 </li>
                  </ul>
                  <div class="TabbedPanelsContentGroup" >
                    <div class="TabbedPanelsContent">Content 1</div>
                    <div class="TabbedPanelsContent">
                      <table align="center" width="400" border="0">
                                <tr>
                                  <td scope="row"><p><strong>Current Balance : Rs 650 </br> Due Date : 11/30/2011 
                                </strong> </p></td>
                                  <td> <input name="button5" type="submit" value="Make a Payment"/>
                                  </td>
                                </tr>
                      </table>
                      <div id="TabbedPanels5" class="HTabbedPanels">
                            <ul class="HTabbedPanelsTabGroup">
                              <li class="TabbedPanelsTab" tabindex="0">Analyse Usage</li>
                              <li class="TabbedPanelsTab" tabindex="0">Call History<br />
                              </li>
                              <li class="TabbedPanelsTab" tabindex="0">Plan Details</li>
                            </ul>
                            <div class="TabbedPanelsContentGroup">
                              <div class="TabbedPanelsContent"><img src="images/chart.PNG" width="658" height="200" /></div>
                              <div class="TabbedPanelsContent">
                             
                               <table width="700" border="0"> <!--Invisible table inside Call History for positioning -->
                                <tr>
                                  <th scope="row">
                                    <table id="datetable" align="center" width="100" height="50" border="1"> <!-- Date Table -->
                                     <tr>
                                      <td scope="row">
                                        <table  border="0"><!-- table for positioning dtae fields .. two rows -->
                                          <tr>
                                           Filter based on Dates
                                           <td scope="row" >From Date:                                    
                                             <script type="text/javascript">
                                             // BeginOAWidget_Instance_2137022: #datepicker
                                                 $(function() {
                                					$("#datepicker").datepicker({ showOtherMonths: false });
				                                              });
                                             // EndOAWidget_Instance_2137022
                                            </script>
                             <input type="text" id="datepicker" class="ui-glass-gradient  ui-80TopTo0Bottom-gradient-header"></input>                                           </td>
                                           <td scope="row" >
                                            To Date:                                       
                                              <script type="text/javascript">
                                               // BeginOAWidget_Instance_2137022: #datepicker_2
              				       				$(function() {
				                                  	$("#datepicker_2").datepicker({ showOtherMonths: false });
                                    				});
                                                // EndOAWidget_Instance_2137022
                                              </script>
                         <input type="text" id="datepicker_2" class="ui-glass-gradient ui-80TopTo0Bottom-gradient-header"></input>
                                          </td>
                                          </h6>
                                          </tr>
                                          <tr>
                                           <td  align="center" scope="row">
                                           <input name="button4" type="submit" value="Update" />
                                           </td>
                                         </tr>
                                      </table>
                                      <!-- End of Datapicker table-->
                                    </td>
                                  </tr>
                                </table>
                                    </br>
                                    <h5> Call History From Last Billed Date </h5>
                                    
                                  <table  align="center"  border="0" id="callhistory">
  <tr>
    <th scope="row">Date/Time</th>
    <th scope="row">Number Called</th>
    <th scope="row">Duration</th>
    <th scope="row">Cost</th>
    <th scope="row">Discount Type</th>

   </tr>
   <tr>
    <td>&nbsp;</td>
   <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
   </tr>
   
  <tr>
     <td>&nbsp;</td>
     <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
     <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>&nbsp;</td>
      <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
                                </th>
                               </tr>
                              </table>

                             </div>
                              <div class="TabbedPanelsContent">Content 3</div>
                            </div>
                      </div>
                    </div>
                  </div>
                </div>
                <p>&nbsp;</p>
              <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="BPEdit" -->Makes Changes in the BPEdit Blue coloured box ( this is editable region ) <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="BHEdit" -->Makes Changes in the BHEdit Blue coloured box ( this is editable region ) <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="SerEdit" -->Makes Changes in the SerEdit Blue coloured box ( this is editable region ) <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="ProEdit" -->
              <div id="breadcrumbs1"> 
                  <h5><a href="#"><font size="2.5">My Account</a> &gt;Profile</h5>
                  <p>&nbsp;</p>
              </div>
                <div id="TabbedPanels6" class="VTabbedPanels">
                  <ul class="TabbedPanelsTabGroup">
                    <li class="TabbedPanelsTab" tabindex="0">Your Profile</li>
                    <li class="TabbedPanelsTab" tabindex="0">Add Payment Information</li>
                    <li class="TabbedPanelsTab" tabindex="0">Auto Payment Setup</li>
                    <li class="TabbedPanelsTab" tabindex="0">Bill Payment Alert</li>
                  </ul>
                  <div class="TabbedPanelsContentGroup">
                    <div class="TabbedPanelsContent">Content 1</div>
                    <div class="TabbedPanelsContent">Content 2</div>
                    <div class="TabbedPanelsContent">Content 3</div>
                    <div class="TabbedPanelsContent">Content 4</div>
                  </div>
                </div>
              <!-- InstanceEndEditable --></div>
            </div>
          </div>
        </div>
        <div class="TabbedPanelsContent">
          <div id="TabbedPanels3" class="TabbedPanels">
            <ul class="TabbedPanelsTabGroup">
              <li class="TabbedPanelsTab" tabindex="0">Mobile</li>
              <li class="TabbedPanelsTab" tabindex="0">Internet</li>
              <li class="TabbedPanelsTab" tabindex="0">Fixed Line</li>
            </ul>
            <div class="TabbedPanelsContentGroup">
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="MobEdit" -->Makes Changes in the MobEdit Blue coloured box ( this is editable region ) <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="InterEdit" -->Makes Changes in the InterEdit Blue coloured box ( this is editable region ) <!-- InstanceEndEditable --></div>
              <div class="TabbedPanelsContent"><!-- InstanceBeginEditable name="FixedEdit" -->Makes Changes in the FixedEdit Blue coloured box ( this is editable region ) 
                <script type="text/javascript">
var TabbedPanels4 = new Spry.Widget.TabbedPanels("TabbedPanels4", {defaultTab:1});
var TabbedPanels5 = new Spry.Widget.TabbedPanels("TabbedPanels5");
var TabbedPanels6 = new Spry.Widget.TabbedPanels("TabbedPanels6");
                </script>
              <!-- InstanceEndEditable --></div>
            </div>
          </div>
        </div>
        <div class="TabbedPanelsContent"> </div>
      </div>
    </div>
    
  <!-- end .content --></div>
  <div class="footer">
  <table width="958" border="1">
    <tr>
      <td width="221" height="29"> <div align="center">About Us</div></td>
      <td width="272"><div align="center">SiteMap</div></td>
      <td width="248"><div align="center">Careers</div></td>
      <td width="189"><div align="center">Contact Us</div></td>
    </tr>
  </table>
  <!-- end .footer --></div>
  <!-- end .container --></div>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
var TabbedPanels2 = new Spry.Widget.TabbedPanels("TabbedPanels2");
var TabbedPanels3 = new Spry.Widget.TabbedPanels("TabbedPanels3");
</script>
</body>
<!-- InstanceEnd --></html>