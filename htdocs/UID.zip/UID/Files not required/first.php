<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>Hello world</p>
<p>&nbsp;</p>
<p><img src="IMG_20111109_072655.jpg" width="384" height="512" alt="helo" /></p>
<table width="200" border="1">
  <tr>
    <td>&nbsp;</td>
    <td>hdsfs</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>dsds</td>
    <td>dsds</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>dsds</td>
    <td>&nbsp;</td>
    <td>dsds</td>
  </tr>
</table>
</body>
</html>