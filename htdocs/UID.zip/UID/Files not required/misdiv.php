
<div id="dialog-overlay5"></div>
                                           <div id="dialog-box5">
                                           	<div class="dialog-content5">
                                             <div id="dialog-message5"></div>
                                             <center>
                                              <h2> Your Checking Account (Primary Account) Details </h2>
                                                <table width="400" height="200" id="tablecss" border="1">
                                                <tr> <td> 
                                                <table width="395" height="195" id="tablecss" border="0">
                                                  <tr><td><b> Bank Name: </b></td> <td> Wells Fargo </td> </tr>
                                                <tr><td><b> Account Type: </b></td> <td> Checking Account </td> </tr> 
                                                <tr><td><b> Account Holder's name: </b></td> <td> Sita </td> </tr> 
                                                <tr><td><b> Account Number: </b></td> <td> 223456789 </td> </tr> 
                                                <tr><td><b> Routing number: </b></td> <td> 11034567 </td> </tr>                                                 </table>
                                                </td></tr></table> <br /><br />
                                                <a href="javascript: closepopup5()" class="buttonCenter">Close</a> 
                                                </center>                                                
                                                </div>
                                          </div> 
                                          
                         <div id="dialog-overlay6"></div>
                                           <div id="dialog-box6">
                                           	<div class="dialog-content6">
                                             <div id="dialog-message6"></div>
                                             <center>
                                             <h2> Your checking account (Secondary Account) Details </h2>
                                                <table id="tablecss" border="1">
                                                <tr> <td> 
                                                <table width="395" height="125" id="tablecss" border="0">
                                                 <tr><td><b> Bank Name: </b></td> <td> US Bank </td> </tr>
                                                <tr><td><b> Account Type: </b></td> <td> Checking Account </td> </tr> 
                                                <tr><td><b> Account Holder's name: </b></td> <td> Sita </td> </tr> 
                                                <tr><td><b> Account Number: </b></td> <td> 223456789 </td> </tr> 
                                                <tr><td><b> Routing number: </b></td> <td> 11034567 </td> </tr>                                                 </table>
                                                </td></tr></table> <br /><br />
                                                <a href="javascript: closepopup6()" class="buttonCenter">Close</a> 
                                                </center>                                                
                                                </div>
                                          </div>                       
                         <div id="dialog-overlay7"></div>
                                           <div id="dialog-box7">
                                           	<div class="dialog-content7">
                                             <div id="dialog-message7"></div>
                                             <center>
                                             <h2> Your Credit Card Details </h2>
                                                <table  id="tablecss" border="1">
                                                <tr> <td> 
                                                <table  width="395" height="180" id="tablecss" border="0">
                                                <tr><td><b> Account Holder's name: </b></td> <td> Sita </td> </tr> 
                                                <tr><td><b> Card Number: </b></td> <td> xxxx-xxxx-xxxx-8999 </td> </tr> 
                                                <tr><td><b> Billing Address: </b></td> <td> 302, MG Road, New Delhi </td> </tr> 
                                                <tr><td><b> Expiration Date: </b></td> <td> 09/13 </td> </tr>
                                                 <tr><td><b> Security Code: </b></td> <td> 786 </td> </tr>                                                 </table>
                                                </td></tr></table> <br /><br />
                                                <a href="javascript: closepopup7()" class="buttonCenter">Close</a> 
                                                </center>                                                
                                                </div>
                                          </div>               
 <div id="dialog-overlay8"></div>
               <div id="dialog-box8">
                	<div class="dialog-content8">
                         <div id="dialog-message8"></div>
                           <!-- <h2 align="center" draggable="true" style="border:thick">
                                <b>E-Receipt<b>-->
                              <table id="tablecss" border="1" align="center" width="450" height="200" >
                              <tr>
                               <td>
                                <table border="0" align="center" width="450" height="50" >
                                  <tr>
                                    <td align="left"  width="50" height="50">
                                       <img src="images/Mainlogo.PNG" width="50" height="50" />
                                    </td>
                                    <td align="center">
                                        E-Receipt
                                    </td>                          
                                 </tr>
                                </table>
                                   
                                <table  id="tablecss" align="center" border="0" width="450" height="150">
                                  <tr>
                                    <td align="left">
                                       Customer Name : Sita
                                    </td>
                                    <td align="right">
                                      <p>Billing Cycle: 09/15/2011-10/15/2011 </p>
                                        </br>
                                      <p>Bill Payment Date : 10/24/2011</p>
                                    </td>                          
                                 </tr>
                                 <tr>
                                   <td align="left">
                                      Account ID:	1236729013247
                                   </td>
                                   <td align="right">
                                      Payment Type- Checking Account 4534 
                                   </td>                          
                                 </tr>
                                 <tr> 
                                    <td align="left">
                                       Billing Address : <p>G-47,Block E </p>
                                       </br><p>Saharunpur</p>
                                    </td>                
                                    <td align="right">
                                       <p>Amount Paid : Rs 325</p>
                                       </br>
                                       <p>Confirmation Code-IDFTUN </p>
                                   </td>                          
                                 </tr>
                                 <tr>
                                    <td align="left">
                                       Contact Number : 9901311271
                                    </td>
                                    <td align="right">
                                    </td>                          
                                </tr>
                             </table>
                            </td>
                            </tr>
                            </table>
                             <br>
                             <a href="javascript: popup9()" class="buttonLeft">Print</a>
                             <a href="javascript: popup10()" class="buttonLeft">email</a>
                             <a href="javascript: closepopup8()" class="buttonRight">Close</a>
                          </div>
                      </div>
              <div id="dialog-overlay9"></div>
               <div id="dialog-box9">
                	<div class="dialog-content9">
                         <div id="dialog-message9"></div>
                            <h2 align="center" draggable="true" style="border:thick">
                                <b>Successfully Printed<b>
                            </h2>
                             <br>
                             <a href="javascript: closepopup9()" class="buttonRight">close</a>
                         </div>
                      </div>
               <div id="dialog-overlay10"></div>
                <div id="dialog-box10">
                	<div class="dialog-content10">
                         <div id="dialog-message10"></div>
                            <h2 align="center" draggable="true" style="border:thick"> </br>
                             <table id="tablecss" align="center" border="1">
                             <tr>
                             <td>
                                <p align="center"> Email To : </p>
                                </br>
                                 <p align="center"> sita@gmail.com </p>
                                 </br>
                                 <p align="center"> or </p>
                                 </br>
                                 <p align="center"> Enter a new email id:<input name="lsadlkj" type="text" /> </p>
                                 </tr>
                                 </td>
                                 </table>
                            </h2>
                             <br>
                             <a href="javascript: closepopup10()" class="buttonRight">close</a>
                             <a href="javascript: popup11()" class="buttonLeft">email</a>
                         </div>
                      </div>
                      
              <div id="dialog-overlay11"></div>
               <div id="dialog-box11">
                	<div class="dialog-content11">
                         <div id="dialog-message11"></div>
                            <h2 align="center" draggable="true" style="border:thick">
                              <b>Receipt Emailed to sita@gmail.com<b>
                            </h2>
                             <br>
                             <a href="javascript: closepopup11()" class="buttonRight">close</a>
                         </div>
                      </div>
                      
              <div id="dialog-overlay12"></div>
               <div id="dialog-box12">
                	<div class="dialog-content12">
                         <div id="dialog-message12"></div>
                            <h2 align="center" draggable="true" style="border:thick">
                              <p>Confirm Card details </p>
                            </h2>
                            
                            <table id="tablecss" width="450"  border="1" align="center">
                            <tr>
                            <td>
                            <table align="center">
                             
                               <tr>
                                 <td> <font size="2">
                               <strong>Account Holder's Name : </strong>Sita </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                  <strong>Card Number :</strong> 5623 2369 3456 7789 </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                 <strong> Billing address :</strong> G-47 Block E Sahranpur </font>                                
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                 <strong> Expiration Date : </strong>08/14 </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                <strong>   Security Code : </strong> 435 </font>
                                 </td>
                              </tr>
                              </table>
                              </td>
                              </tr>
                              </table>                       
                           
                                    <br>
                                    
                              <a href="javascript:PayModeAdd()" class="buttonLeft">confirm</a>
                             <a href="javascript: closepopup12()" class="buttonRight">close</a>
                         </div>
                      </div>
                      
                      <!-- ---------------------------------------------------------------------------------- -->
              <div id="dialog-overlay14"></div>
               <div id="dialog-box14">
                	<div class="dialog-content14">
                         <div id="dialog-message14"></div>
                            <h2 align="center" draggable="true" style="border:thick">
                              <p>Confirm Card details </p>
                            </h2>
                              
                            <table id="tablecss" border="1" align="center" width="400" height="220">
                             <tr>
                                 <td> <font size="2">
                                  Bank Name: Wells Fargo </font>
                                 </td>
                              </tr>
                              <tr>
                                 <td> <font size="2">
                                  Account Type: Checking Account </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                  Account Holder's Name : Sita </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                  Account Number : 5623 2369 3456 7789 </font>
                                 </td>
                              </tr>
                               <tr>
                                 <td> <font size="2">
                                  Routing Number :  G-47 Block E Saharanpur </font>
                                  <br />
                                 </td>
                              </tr>                              
                              </table>
                                    <br>
                                    
                              <a href="javascript:PayModeAdd()" class="buttonLeft">confirm</a>
                             <a href="javascript: closepopup14()" class="buttonRight">close</a>
                         </div>
                      </div>
                      
 <!-- ---------------------------------- -->                     
  <div id="dialog-overlay16"></div>
   <div id="dialog-box16">
  <div class="dialog-content16">
  
   <div id="dialog-message16"></div>
	<h2 align="center"  style="border:thick"><b>Are you sure you want to change your present plan to Garuda 1000 rate      plan?<b></h2>
     <br>
       <a href="http://localhost:81/UID/meter1.php" class="buttonLeft">Confirm</a>
        <a href="javascript: closepopup16()" class="buttonRight">Close</a>    
        </div>
</div>
<!-- ---------------------------------- -->
<div id="dialog-overlay"></div>
<div id="dialog-boxSubscribeMe">
	<div class="dialog-contentSubscribeMe">
    
    
		<div id="dialog-message"></div>
	
<h2 align="left"><b>More Information</h2>
<table id="tablecss" width="200" border="0">
  <tr>
    <td><label>First Name*</label></td>
    <td><input name="Fname" type="text" /></td>
  </tr>
 
  <tr>
    <td><label>Last Name*</label></td>
    <td><input name="Lname" type="text" /></td>
  </tr>
   <tr>
    <td><label>Middle Initial</label></td>
    <td><input name="Minitial" type="text" /></td>
  </tr>
  <tr>
    <td><label>Email*</label></td>
    <td><input name="Email" type="text" /></td>
  </tr>
  <tr>
    <td> <a href="javascript:popupSubscriptionSuccessful()" class="buttonLeft" style="color:#FFF">Subscribe</a></td>
    <td> <a href="javascript:closepopupSubscribeMe()" class="buttonRight" style="color:#FFF">Cancel</a></td>
  </tr>
</table>

<br>

     
	</div>
</div>


<div id="dialog-overlay"></div>
<div id="dialog-boxApply">
	<div class="dialog-contentApply">
    
    
		<div id="dialog-message"></div>
        <h3 align="center"><b>Information Required</h3>
 <table id="tablecss" width="350" border="1">
  <tr>
    <td><font color="#330033">Please enter your login id</td>
    <td><input name="loginid" type="text" /></td>
  </tr>
  <tr>
    <td> <font color="#330033">Enter your phone number (if you don't have a login id)</td>
    <td><input name="phno" type="text" /></td>
  </tr>
</table>

<table  width="200" border="0">
  <tr>
    <td> <a href="javascript:popupApplyConfirm('')" class="buttonRight" style="color:#FFF">Ok</a></td>

  </tr>
</table> 
	</div>
</div>



<div id="dialog-overlay"></div>
<div id="dialog-boxApplyConfirm">
	<div class="dialog-contentApplyConfirm">
    
    
		<div id="dialog-message"></div>
       

<table align="center" id="tablecss" width="200" border="0">
<tr>
<td align="center">
Application has been loged, we will contact you shortly.
</td>
</tr>
  <tr>
    <td> <a href="javascript:closepopupApplyConfirm()" class="buttonRight" style="color:#FFF">Ok</a></td>

  </tr>
</table> 
	</div>
</div>




<div id="dialog-overlay"></div>
<div id="dialog-boxSubscriptionSuccessful">
	<div class="dialog-contentSubscriptionSuccessful">
    
    
		<div id="dialog-messageSubscriptionSuccessful"></div>
	
<h3 align="left"><b>Subscription successful<br>An email has been sent to your account for verifications.</h3>
<table id="tablecss" width="200" border="0">
  <tr>
    <td> <a href="javascript:closepopupSubscriptionSuccessful()" class="buttonRight" style="color:#FFF">OK</a></td>
  </tr>
</table> 
	</div>
</div>