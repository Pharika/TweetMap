// Run the script on DOM ready:
$(function(){
		 $('select').selectmenu();
});