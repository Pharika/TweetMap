<?php
echo $_GET['ur'];
?>
