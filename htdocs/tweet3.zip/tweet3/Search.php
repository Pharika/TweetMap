<html>
<HEAD>
<TITLE>A simple frameset document</TITLE>
</HEAD>
<frameset rows="20%,80%" >
  <frame name="one" src="Search1.php"/>
  <frameset cols="50%,50%">
    <frame name="two" src="Search2.php" />
    <frame name="three" src="MarkerMAp.php" />
  </frameset>

</html>
