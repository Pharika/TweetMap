
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"> 
  <head> 
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/> 
    <title>Google Maps JavaScript API Example: Event Arguments</title> 
    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAPE4WoS1rHy2fjeKDNLTPNhRkSy9yzul_YnVdsjGSmU1DXZqN6RTmR5XzQSdD7xjmcpWdUlD9Lxohnw"
            type="text/javascript"></script> 
	<link rel="stylesheet" href="search.css" type="text/css" media="screen" /> 	
	<link rel="stylesheet" href="srch.css" type="text/css" media="screen" /> 
	<script type="text/javascript"> 
  var map;
var geocoder;
var address;
var s;
function initialize() {
  map = new GMap2(document.getElementById("map_canvas"));
  map.addControl(new GLargeMapControl());
        map.addControl(new GMapTypeControl());
		
        map.setCenter(new GLatLng(40.730885,-73.997383), 15);
  GEvent.addListener(map, "click", getAddress);
  geocoder = new GClientGeocoder();
  var markerBounds = new GLatLngBounds();
}

	function getAddress(overlay, latlng) {
  if (latlng != null) {
 window.open('Search2.php?L1=' + encodeURIComponent(latlng.y) + '&L2=' + encodeURIComponent(latlng.x) + '&rad=' + encodeURIComponent(document.getElementById('radiusbox').value),'two');
  map.clearOverlays();
  marker = new GMarker(latlng);
  map.addOverlay(marker);
 map.openInfoWindow(latlng,"Latitude:" + latlng.x + "Longitude:" + latlng.y);
  }
}


var latt="<?php echo $_GET['Loca'];?>";
if(latt)
{
//alert("in mark" + latt);
var locat= latt.split("%");
//for(i=0;i<myS.length;i++)
//{
//alert("split:" + i +")" +myS[i]);
//getl(myS[0]);

//}
geocoder = new GClientGeocoder();
for(i=0;i<10;i++)
{
//alert("hello dude");
if (geocoder) {
        alert("hello" + locat[i]);
        geocoder.getLatLng(locat[i],function(point) {
          if (!point) {
         alert(address + " not found");
            } else {
			   alert("point:" + point);
             // map.setCenter(point, 13);
              var marker = new GMarker(point);
              map.addOverlay(marker);
            }
          }
        );
      }
	  else
	  {
	  alert("dead");
	  }
	  
	  }

}

function getl(locat)
{
var locat=new Array("40.73291740326451, -74.00167465209961","40.72859216749113, -73.99819850921631");
for(i=0;i<2;i++)
{
if (geocoder) {
        //alert("hello");
        geocoder.getLatLng(locat[i],function(point) {
          if (!point) {
         alert(address + " not found");
            } else {
			   //alert(point);
              map.setCenter(point, 13);
              var marker = new GMarker(point);
              map.addOverlay(marker);
            }
          }
        );
      }
	  }
	 } 

</script>
	
  </head>

 <BODY onload="initialize()" onunload="GUnload()" style="background-color: #4099FF;">
        <label>Enter the Radius of the search in miles:</label>
	<input type ="text" name="rad" id = "radiusbox"/> 
	<div id = "map_canvas" style="width: 500px; height: 400px">
	
	</div>
	 <input type="text" size="60" name="address" id="ltlg"/> 
       <input type ="button" value="Search" id = "b1" onclick="getl();"\>
	
</script>
 </BODY>
</HTML>