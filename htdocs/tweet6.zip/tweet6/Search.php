<html>
<HEAD>
<TITLE>A simple frameset document</TITLE>
</HEAD>
<frameset rows="20%,80%" BORDERCOLOR="#000000" >
  <frame name="one" src="Search1.php"/>
  <frameset cols="50%,50%">
    <frame name="two" src="Search2.php" />
    <frame name="three" src="mapv3.php" />
  </frameset>

</html>
