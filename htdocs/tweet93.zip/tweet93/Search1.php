<html>
  <HEAD>
   <TITLE>A simple frameset document</TITLE>
    <link rel="stylesheet" href="srch.css" type="text/css" media="screen" /> 	
  </HEAD>
  <body align="center" style="background-color: #282828">
     <div id="search" class="search">
         <form target="two" action="Search2.php"  method="get">
         Tweeting With Maps
         <br><br>
         Search twitter
         <input type="text" name="q" id="searchbox" />
         <input type="submit" id="mysubmit" name="submit" id="submit" value="Search" />
         <br>
         </form>
     </div>
   </body>
</html>